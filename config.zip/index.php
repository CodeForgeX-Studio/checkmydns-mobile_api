<?php
header('Location: https://checkmydns.online', true, 301);
exit;